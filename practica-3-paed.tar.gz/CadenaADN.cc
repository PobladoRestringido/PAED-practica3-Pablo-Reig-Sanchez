#include "CadenaADN.h"
#include <fstream>
using namespace std;


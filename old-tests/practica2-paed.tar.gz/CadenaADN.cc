#include "CadenaADN.h"
#include <fstream>
using namespace std;


//Constructor por defecto
CadenaADN::CadenaADN(){
   
}

//Constructor sobrecargado
CadenaADN::CadenaADN(const string &sec, const string &desc){
   
}


//Constructor de copia
CadenaADN::CadenaADN(const CadenaADN & cad){
   
}

//Destructor:
CadenaADN::~CadenaADN(){
   
}

//Operador de asignación
CadenaADN& CadenaADN::operator=(const CadenaADN &cad){
   return *this;
}

//Operadores de comparación
bool CadenaADN::operator==(const CadenaADN &cad) const{
     return false;
}

bool CadenaADN::operator!=(const CadenaADN & cad) const{
     return false;
}

//Getters y setters
string CadenaADN::getSecuencia() const{
    return "";
}
string CadenaADN::getDescripcion() const{
   return "";
}

int CadenaADN::getLongitud() const{
   return 0;
}


bool CadenaADN::setSecuencia(const string &sec){
      return false;
}


void CadenaADN::setDescripcion(const string &desc){

}

//Cuentas de nucleótidos
int CadenaADN::cuentaA() const{
   return 0;
}
int CadenaADN::cuentaT() const{
     return 0;
}
int CadenaADN::cuentaC() const{
     return 0;
}
int CadenaADN::cuentaG() const{
    return 0;
}

bool CadenaADN::cumpleChargaff() const{
   return false;
}

double CadenaADN::proporcionGC() const{
   
   return 0.0;
}

//Búsqueda de codones
int CadenaADN::contarCodon(const string & codon) const{
   return 0;
}

//Búsqueda de subsecuencias
int CadenaADN::buscarSubsecuencia(const string &str) const{
   return -1;
}

int CadenaADN::posicionUltimaAparicion(const string &str) const{
   return -1;
}

//Búsqueda de elementos consecutivos
int CadenaADN::longitudMaximaConsecutiva(char nuc) const{
    return 0;
}
int CadenaADN::longitudMaximaConsecutivaCualquiera() const{
    return 0;

}

//Mutaciones
bool  CadenaADN::mutar(int posicion, char nuc){
    return false;
}

int  CadenaADN::contarMutaciones(const CadenaADN &cad) const{
   return 0;
}

//Secuencias complementarias
bool CadenaADN::esSecuenciaComplementaria(const CadenaADN& cad) const{
   
   return false;
}

//Modificaciones
void CadenaADN::invertir() {
 
}

//Almacenaje y lectura de fichero
bool CadenaADN::guardarEnFichero(const string &nombre) const{
      return false;
}

bool CadenaADN::cargarDesdeFichero(const string &nombre){
   return false;
}

